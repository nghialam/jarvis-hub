# BACKLOG — Jarvis Hub 2.0 — Consolidated & Trimmed [2026-08-15]

|||||| ID | Prio | Category | Title | Status | Notes |
||||||---|---|---|---|---|---|
|||||| J20 | P1 | Feature | Jarvis Hub 2.0 Implementation | In Progress | Flask dashboard on port 8100; ~60 API routes, 38 DB tables — **Phases A-B done Jul 25, C-E pending** |
|||||| N01 | P1 | Feature | AI News Sentinel Construction | Open | Phase 1 of dashboard expansion — stalled |
|||||| S02 | P1 | System | Skill Namespace Normalization | Open | Audit `openclaw:*`/`finance:*` refs → bare strings |
|||||| C04 | P2 | Error | Regression QA Silent Fail | Open | Keep running, verify weekly |
|||||| CTX01 | P2 | System | Context Overflow Monitoring | Open | Session overflow Jun 22 — monitor LCM tuning |
|||||| M01 | P2 | System | Health Monitoring Cron | Open | Plan: add simple /health cron checker |
|||||| H01 | P2 | System | Codebase Bloat Cleanup | Open | Prune old .py from knowledge/scripts/ dirs |
|||||| CRON01 | P2 | Error | Cron Timeout Pattern (memory-daily + backlog-sync) | Open | qwen3.6:35b too slow for 600s deadline — consider migrating to 27b-mxfp8 |
|||||| AI01 | P3 | Experiment | Multimodal input pipeline (vision) | Open | Feed charts + text into qwen3.6 via vision variant |
|||||| AI02 | P1 | Error | ModuleNotFoundError: vnstock in jarvis-auto-improve | Open | 10 occurrences — cron daemon không kích hoạt Hermes venv, PYTHONPATH sai |
|||||| AI03 | P1 | Error | RuntimeError: Connection error vnstock API | Open | 8 occurrences — network/server down hoặc rate limit |
|||||| AI04 | P2 | Error | Invalid reasoning value 'ultra' | Open | 4 occurrences — API trả lỗi, cần validate input params |
|||||| HUB01 | P1 | Error | Ollama không kết nối | Open | `curl localhost:11434` không respond — app.py báo `HTTPConnectionPool` error |
|||||| HUB02 | P1 | Error | Cache stale trong /api/health | Open | `cache_age_seconds: 416438` (~4.8 ngày) — data không được refresh |
|||||| HUB03 | P2 | Error | Routes 404: /api/quotes, /api/knowledge, /api/backlog, /api/alerts | Open | 4 routes không được register trong Flask URL map |
|||||| HUB04 | P2 | Error | Pages 404: /dashboard, /admin | Open | Không có route handler cho 2 pages này |
|||||| HUB05 | P3 | Data | DB data thin (placeholder 47 rows) | Open | Tất cả tables đều 47 rows — dữ liệu seed/test, không phải real data |
|||||| HUB06 | P3 | Code | core/_fix_tier2.py syntax error | Open | Line 35: escaped quote `'` trong string — không ảnh hưởng app (không import) |

--- Daily Autoupdate 2026-08-20 09:14 ---
|- Backlog audit: **18 active items, 0 new** (all 3 candidates were meta compact skips / negative findings). Pipeline idle — day 15.
|- Fact extraction pipeline returning zero new facts (8+ consecutive empty scans).
|- No new learnings, errors, or feature updates to incorporate.

|--- Daily Autoupdate 2026-08-22 09:14 ---
|- Backlog audit: **18 active items, 0 new** (all 8 candidates were meta compact skips / negative findings). Pipeline idle — day 17.
|- Fact extraction pipeline returning zero new facts (10+ consecutive empty scans).
|- No new learnings, errors, or feature updates to incorporate.

|--- Daily Autoupdate 2026-08-23 09:31 ---
|- Backlog audit: **18 active items, 0 new** (all 14 candidates were meta compact skips / negative findings from 2026-08-21 & 2026-08-22). Pipeline idle — day 18.
|- Fact extraction pipeline returning zero new facts (12+ consecutive empty scans).
|- No new learnings, errors, or feature updates to incorporate.

--- Daily Autoupdate 2026-08-24 ---
- System self-audit completed
- Health: {"flask_8100": "unreachable", "ollama": "not loaded", "sqlite_db": "ok", "git_changes": "dirty"}
