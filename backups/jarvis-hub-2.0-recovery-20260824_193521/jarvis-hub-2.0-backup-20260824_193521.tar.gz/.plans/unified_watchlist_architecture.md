# Jarvis Hub Unified Architecture Plan

## Problem
Hiện tại có 2 watchlist sources tách biệt:
- **Flask Dashboard (app.py)**: sqlite DB (`jarvis.db` table `watchlist`) — dùng cho UI display
- **Trading Bot Scripts**: JSON file (`watchlist.json`) — dùng cho cron scans & intraday polling

→ Gây ra trạng thái bất đồng bộ, khó maintain, mỗi lần thêm symbol phải edit 2 nơi.

## Goal
**Single source of truth architecture:**
1. Unified DB table thay thế JSON config
2. Dashboard hiển thị đầy đủ thông tin cơ bản + kỹ thuật trên UI
3. Alert system (Telegram cron jobs) sync cùng data source, push signals real-time
4. Signal engine unified cho cả VN stocks & US equities/crypto

## Phase 1: Centralized Watchlist DB Layer

### 1.1 Schema mới (jarvis.db)
```sql
-- Symbol metadata (updated từ API/API providers)
CREATE TABLE IF NOT EXISTS watchlist_symbols (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol VARCHAR(20) UNIQUE NOT NULL,           -- Ticker: VCI, AAPL, BTC
    name TEXT,                                    -- Full name
    asset_type VARCHAR(20) DEFAULT 'VN_STOCK',    -- VN_STOCK | US_EQUITY | CRYPTO | ETF | OTHER
    market VARCHAR(50),                           -- STO/UPX/Upscale (VN) OR EXCHANGE (US)
    board VARCHAR(20),                            -- G1, T1, etc.
    sector TEXT,                                  -- Banking, RealEstate, Gaming
    industry TEXT,                                -- cụ thể hơn
    
    -- Price & market data (updated by refresh loop)
    last_price REAL,                              -- Giá đóng/cuối cùng
    change_pct REAL,                              -- Pct change (%)
    volume REAL,                                  -- Volume traded
    bid1 REAL, ask1 REAL,                         -- Best bid/ask
    bid1_vol REAL, ask1_vol REAL,                 -- At best level
    
    -- Technical indicators (computed by signal_engine)
    macd_line REAL, signal_line REAL, histogram REAL,       -- MACD
    rsi REAL,                          -- RSI(14)
    ema_50 REAL, ema_200 REAL,                         -- EMAs  
    sma_volume REAL,                             -- SMA Volume 20-day
    
    metadata TEXT,                           -- JSON blob cho field extras (pe_ratio, market_cap, etc.)
    
    -- Config & tracking
    added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_symbol(symbol),
    INDEX idx_asset(asset_type),
    INDEX idx_sector(sector)
);

-- Signals/alerts log (cho Telegram cron jobs to read)
CREATE TABLE IF NOT EXISTS signals_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol VARCHAR(20) NOT NULL,
    asset_type VARCHAR(20),
    signal_type VARCHAR(50),                  -- BUY/SELL/HOLD/STOP_LOSS/POCKET_PIVOT/etc.
    strength REAL DEFAULT 0,                   -- 0-100 score
    price REAL,                              -- Price at signal time
    details TEXT,                            -- JSON: reason, indicators, recommendations
    
    detected_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    delivered BOOLEAN DEFAULT FALSE,         -- Track if sent via Telegram
    delivery_channel VARCHAR(50),            -- telegram:gotham / telegram:private
    
    INDEX idx_symbol_time(symbol, detected_at),
    INDEX idx_unread(asset_type, signal_type)
);

-- History log (optional - for trends over time)
CREATE TABLE IF NOT EXISTS price_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol VARCHAR(20) NOT NULL,
    date DATE NOT NULL,                      -- YYYY-MM-DD
    open REAL, high REAL, low REAL, close REAL, volume REAL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(symbol, date),
    INDEX idx_symbol_date(symbol, date DESC)
);
```

### 1.2 Migration script (migrate_watchlist.py)
- Đọc `watchlist.json` + DB existing data
- Dedupe + merge symbols
- Auto-detect asset_type từ symbol prefix/ticker convention
- Populate metadata nếu có (DNSE secdef cho VN, Yahoo Finance cho US/crypto)

## Phase 2: Unified API Endpoints

### Replace current `/api/watchlist` endpoints
```python
# Unified watchlist CRUD (replaces JSON config + separate DB table)
@app.route("/api/symbols", methods=["GET"])     # List all symbols w/ type filter
@app.route("/api/symbols/<symbol>", methods=["GET"])      # Single symbol detail  
@app.route("/api/symbols/<symbol>/history")   # Price history for charting
@app.route("/api/symbols/<signal_type>")       # Filter signals by type

# Data refresh triggers
@app.route("/api/refresh/all", methods=["POST"])    # Trigger full cache refresh
@app.route("/api/refresh/signal/<symbol>", methods=["POST"])  # Refresh one symbol
```

## Phase 3: Dashboard Enhancement

### Add new tabs/sections to dashboard UI:
1. **"Signals" tab** — Real-time signal feed (như Bloomberg terminal style)  
2. **"Stock Details" page/modal** — Click một symbol → show full analysis:
   - Price chart canvas + EMA overlay 
   - Technical indicators table (RSI, MACD, MA cross)
   - Bid/ask ladder visualization
   - Sector/industry metadata card
3. **"Overview" dashboard** — Grid view all symbols grouped by asset_type

### Implementation:
- Extend app.py routes for `/api/symbols/detail/<symbol>`
- Create `/templates/symbol_detail.html` template
- Add frontend JS charting + signal polling via fetch/WebSocket

## Phase 4: Telegram Alert Integration

### Update cron jobs to read from DB:
- `scan_reporter.py`: reads signals từ `signals_log`, sends formatted alerts
- `intraday_scan_poller.py`: writes new signals vào DB + delivers if threshold met
- Signal detection logic unified trong `signal_engine.py` (common to both)

### Alert format:
```
🚨 ALERT | VCI | 📈 BUY SIGNAL
Price: 24.7 (+1.5% intraday)
Signal: Pocket Pivot detected + RSI crossing above 30  
Volume surge: 180% vs 20-day average
Target: ~26.5 (breakout resistance)
Stop loss: Below 23.8 → risk/reward = 1:2
```

## Phase 5: Signal Engine Integration

### Current `market_data.py` needs update:
- Replace `_load_watchlist_symbols()` → read from DB instead of JSON
- Update `fetch_all_stocks()` → batch fetch từ DNSE + Yahoo Finance unified
- Add technical indicator computations (RSI, MACD, EMA crossovers)

### `signal_engine.py` enhancements:
- Pocket Pivot detection already exists? → extend to all signals
- Add pattern recognition (support/resistance levels from price history)
- Volume analysis (surge/decline vs average)
- Combine multiple indicators into composite signal score

## Implementation Order

1. **DB schema + migration** → tạo table mới + migrate data JSON → DB
2. **API layer update** → thay thế endpoints cũ bằng unified version  
3. **Market_data refactor** → đọc từ DB, không còn JSON config
4. **Signal engine** → thêm computed columns cho watchlist_symbols
5. **Dashboard UI** → thêm tabs/sections mới cho signals/detail view
6. **Telegram alerts** → cron jobs read từ signals_log table

## Files to modify:
- `db.py` hoặc tạo riêng: schema + migration logic  
- `app.py`: routes, data refresh loop, signal detection integration
- `scripts/trading_bot/market_data.py`: read from DB instead of JSON
- `scripts/trading_bot/signal_engine.py`: compute indicators 
- `scripts/trading_bot/scan_reporter.py`: read signals từ DB → send Telegram
- `scripts/trading_bot/unified_scan.py`: write signals to DB

## Risk & Mitigation
- ❌ Breaking existing cron schedules: ✅ Keep JSON fallback during migration  
- ❌ Database size growth: ✅ Archive old signals/prices periodically
- ❌ Slow queries: ✅ Proper indexes on symbol, timestamp

