#!/usr/bin/env python3
import sqlite3, os

for db_name in ['jarvis_hub.db', 'database.db', 'jarvis.db', 'data/app.db', 'watchlist.db']:
    try:
        conn = sqlite3.connect(db_name)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [r[0] for r in cursor.fetchall()]
        conn.close()
        if tables:
            print(f"{db_name}: {len(tables)} tables: {tables[:10]}...")
        else:
            print(f"{db_name}: no tables")
    except Exception as e:
        print(f"{db_name}: ERROR {e}")
